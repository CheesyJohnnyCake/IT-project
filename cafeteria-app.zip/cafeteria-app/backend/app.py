# backend/app.py
import json
import os
import datetime
from flask import Flask, request, jsonify
from flask_cors import CORS

app = Flask(__name__)
CORS(app) # Enable CORS for frontend interaction

# --- Data Storage ---
# Initial menu items (in memory for simplicity)
menu_items = {
    "Hotdog": 2.50,
    "Burrito": 3.00,
    "Nachos": 3.50,
    "Pizza": 4.00,
    "Taco": 2.00,
    "Quesadilla": 3.50,
    "Water": 1.00,
    "Soda": 2.00,
    "Juice": 2.00,
}

# Order history storage (using a JSON file for basic persistence)
HISTORY_FILE = 'orders.json'
order_history = []

def load_history():
    """Loads order history from the JSON file."""
    global order_history
    if os.path.exists(HISTORY_FILE):
        #add if password entered here is correct then try
        try:
            with open(HISTORY_FILE, 'r') as f:
                order_history = json.load(f)
        except (json.JSONDecodeError, FileNotFoundError):
            # Handle case where file is empty, corrupt, or somehow disappears
            order_history = []
            print(f"Warning: Could not read {HISTORY_FILE}. Starting with empty history.")
        except Exception as e:
            print(f"An unexpected error occurred loading history: {e}")
            order_history = []
    else:
        order_history = []
        print(f"No history file found: {HISTORY_FILE}. Starting with empty history.")

def save_history():
    """Saves the current order history to the JSON file."""
    try:
        with open(HISTORY_FILE, 'w') as f:
            json.dump(order_history, f, indent=4)
    except Exception as e:
        print(f"Error saving history to {HISTORY_FILE}: {e}")

# Load history when the app starts
load_history()


# --- API Endpoints ---

# Endpoint to get the menu
@app.route('/api/menu', methods=['GET'])
def get_menu():
    """Returns the current menu items."""
    menu_list = [{"name": name, "price": price} for name, price in menu_items.items()]
    return jsonify(menu_list)

# Endpoint to process an order
@app.route('/api/order', methods=['POST'])
def process_order():
    """Processes the customer's order and saves to history."""
    order_data = request.json # Expecting a list of {"name": "item_name", "quantity": X}

    if not order_data:
        return jsonify({"message": "No items in order"}), 400

    subtotal = 0
    ordered_items = [] # List to store items with calculated price for receipt

    for item in order_data:
        item_name = item.get('name')
        quantity = item.get('quantity', 0)

        if not item_name or not isinstance(quantity, int) or quantity <= 0:
             # Skip invalid items or items with quantity <= 0
             continue

        if item_name not in menu_items:
            # Optionally handle items not on the menu
            continue # Skip unknown items or return an error

        price_per_item = menu_items[item_name]
        item_total = price_per_item * quantity
        subtotal += item_total
        ordered_items.append({
            "name": item_name,
            "quantity": quantity,
            "price_per_item": price_per_item,
            "item_total": round(item_total, 2) # Round item totals too
        })

    if not ordered_items:
         return jsonify({"message": "Order contained only invalid or empty items"}), 400

    # Calculate tax (example: 10%)
    tax_rate = 0.10
    tax_amount = subtotal * tax_rate
    total = subtotal + tax_amount

    receipt_data = {
        "timestamp": datetime.datetime.now().isoformat(), # Add timestamp
        "items": ordered_items,
        "subtotal": round(subtotal, 2),
        "tax": round(tax_amount, 2),
        "total": round(total, 2)
    }

    # Add the new order to history and save
    order_history.append(receipt_data)
    save_history()

    return jsonify(receipt_data), 200

# New Endpoint to get order history
@app.route('/api/history', methods=['GET'])
def get_history():
    """Returns the full order history."""
    # Return history in reverse chronological order (most recent first)
    return jsonify(list(reversed(order_history)))


# --- CRUD Endpoints for Items (Potential Admin Use) ---
# (Keep these the same as before, they don't directly interact with history)

@app.route('/api/items', methods=['GET'])
def get_all_items():
    """Returns all menu items (same as get_menu for now)."""
    return jsonify([{"name": name, "price": price} for name, price in menu_items.items()])

@app.route('/api/items', methods=['POST'])
def add_item():
    """Adds a new item. Expects {"name": "new_item", "price": X.XX}."""
    item_data = request.json
    name = item_data.get('name')
    price = item_data.get('price')

    if not name or price is None:
        return jsonify({"message": "Missing name or price"}), 400
    if name in menu_items:
        return jsonify({"message": f"Item '{name}' already exists"}), 409

    try:
        price = float(price)
        if price < 0:
             return jsonify({"message": "Price cannot be negative"}), 400
        menu_items[name] = price
        return jsonify({"message": f"Item '{name}' added", "item": {"name": name, "price": price}}), 201
    except ValueError:
        return jsonify({"message": "Invalid price format"}), 400


@app.route('/api/items/<string:item_name>', methods=['PUT'])
def update_item(item_name):
    """Updates an existing item's price. Expects {"price": X.XX}."""
    if item_name not in menu_items:
        return jsonify({"message": f"Item '{item_name}' not found"}), 404

    item_data = request.json
    price = item_data.get('price')

    if price is None:
         return jsonify({"message": "Missing price in update data"}), 400

    try:
        price = float(price)
        if price < 0:
             return jsonify({"message": "Price cannot be negative"}), 400
        menu_items[item_name] = price
        return jsonify({"message": f"Item '{item_name}' updated", "item": {"name": item_name, "price": price}}), 200
    except ValueError:
        return jsonify({"message": "Invalid price format"}), 400


@app.route('/api/items/<string:item_name>', methods=['DELETE'])
def delete_item(item_name):
    """Deletes an item."""
    if item_name not in menu_items:
        return jsonify({"message": f"Item '{item_name}' not found"}), 404

    del menu_items[item_name]
    return jsonify({"message": f"Item '{item_name}' deleted"}), 200


if __name__ == '__main__':
    # Run the app on http://127.0.0.1:5000/
    app.run(debug=True)