import React from 'react';

function Receipt({ receiptData, onNewOrder }) {
  if (!receiptData) return null;

  return (
    <div className="receipt">
      <h2>Order Receipt</h2>
      <div className="receipt-items">
        {receiptData.items.map((item, index) => (
          <div key={index} className="receipt-item">
            <span>{item.name} x {item.quantity} (${item.price_per_item.toFixed(2)} each)</span>
            <span>${item.item_total.toFixed(2)}</span>
          </div>
        ))}
      </div>
      <div className="receipt-summary">
        <p>Subtotal: ${receiptData.subtotal.toFixed(2)}</p>
        <p>Tax: ${receiptData.tax.toFixed(2)}</p>
        <h3>Total: ${receiptData.total.toFixed(2)}</h3>
      </div>
      <button className="start-new-order-button" onClick={onNewOrder}>
        Start New Order
      </button>
    </div>
  );
}

export default Receipt;