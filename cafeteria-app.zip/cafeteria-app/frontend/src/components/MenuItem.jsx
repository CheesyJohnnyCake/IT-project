// frontend/src/components/MenuItem.jsx
import React from 'react';

function MenuItem({ item, onAddToCart }) {
  return (
    <li className="menu-item">
      <span>{item.name} - ${item.price.toFixed(2)}</span>
      <button onClick={() => onAddToCart(item)}>Add to Cart</button>
    </li>
  );
}

export default MenuItem;