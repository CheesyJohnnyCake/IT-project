import React from 'react';

function Cart({ cart, menu, onUpdateQuantity, onRemoveItem, onPlaceOrder }) {
  // Calculate subtotal
  const subtotal = Object.entries(cart).reduce((sum, [itemName, quantity]) => {
    const item = menu.find(m => m.name === itemName);
    return sum + (item ? item.price * quantity : 0);
  }, 0);

  const cartItemsList = Object.entries(cart).map(([itemName, quantity]) => {
      const item = menu.find(m => m.name === itemName);
      if (!item) return null; // Should not happen if cart matches menu

      const itemTotal = item.price * quantity;

      return (
          <li key={itemName} className="cart-item">
              <div className="item-info">
                  {item.name} - ${item.price.toFixed(2)} x {quantity}
              </div>
              <input
                  type="number"
                  min="0"
                  value={quantity}
                  onChange={(e) => {
                      const newQuantity = parseInt(e.target.value, 10);
                      if (!isNaN(newQuantity) && newQuantity >= 0) {
                          onUpdateQuantity(itemName, newQuantity);
                      }
                  }}
              />
              <button onClick={() => onRemoveItem(itemName)}>Remove</button>
          </li>
      );
  }).filter(Boolean); // Remove any null entries

  return (
    <div className="cart-section">
      <h2>Your Order</h2>
      {cartItemsList.length === 0 ? (
        <p>Your cart is empty.</p>
      ) : (
        <>
          <ul className="cart-list">
            {cartItemsList}
          </ul>
          <div className="cart-summary">
            <p>Subtotal: ${subtotal.toFixed(2)}</p>
          </div>
          <button
              className="place-order-button"
              onClick={onPlaceOrder}
              disabled={cartItemsList.length === 0}
          >
            Place Order
          </button>
        </>
      )}
    </div>
  );
}

export default Cart;