import React, { useState } from 'react';

function OrderHistory({ history }) {
  // State to manage which order details are expanded
  const [expandedOrder, setExpandedOrder] = useState(null);

  const toggleDetails = (index) => {
    if (expandedOrder === index) {
      setExpandedOrder(null); // Collapse if already expanded
    } else {
      setExpandedOrder(index); // Expand this order
    }
  };

  if (!history || history.length === 0) {
    return (
      <div className="order-history-section container">
        <h2>Order History</h2>
        <p>No orders placed yet.</p>
      </div>
    );
  }

  return (
    <div className="order-history-section container">
      <h2>Order History</h2>
      <ul className="history-list">
        {history.map((order, index) => (
          <li key={index} className="history-item">
            <div className="history-summary">
              {/* Basic summary line */}
              <span>
                Order #{history.length - index} - {new Date(order.timestamp).toLocaleString()}
              </span>
              <span>
                Total: ${order.total.toFixed(2)}
              </span>
              <button onClick={() => toggleDetails(index)}>
                {expandedOrder === index ? 'Hide Details' : 'Show Details'}
              </button>
            </div>
            {/* Detailed items, shown conditionally */}
            {expandedOrder === index && (
              <div className="history-details">
                <ul>
                  {order.items.map((item, itemIndex) => (
                    <li key={itemIndex}>
                      {item.name} x {item.quantity} (${item.price_per_item.toFixed(2)} each) - ${item.item_total.toFixed(2)}
                    </li>
                  ))}
                </ul>
                 <div className="history-summary-detail">
                    <p>Subtotal: ${order.subtotal.toFixed(2)}</p>
                    <p>Tax: ${order.tax.toFixed(2)}</p>
                    <p>Total: ${order.total.toFixed(2)}</p>
                 </div>
              </div>
            )}
          </li>
        ))}
      </ul>
    </div>
  );
}

export default OrderHistory;