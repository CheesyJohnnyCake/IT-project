import React from 'react';
import MenuItem from './MenuItem';

function Menu({ menu, onAddToCart }) {
  return (
    <div className="menu-section">
      <h2>Menu</h2>
      {menu.length === 0 ? (
          <p>Loading menu...</p>
      ) : (
        <ul className="menu-list">
          {menu.map(item => (
            <MenuItem key={item.name} item={item} onAddToCart={onAddToCart} />
          ))}
        </ul>
      )}
    </div>
  );
}

export default Menu;